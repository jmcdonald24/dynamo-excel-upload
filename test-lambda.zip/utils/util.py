def test_message():
    return "Hello from the test message function"